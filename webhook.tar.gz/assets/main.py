"""FIRELINE static build: posts new personal bests to a Slack workflow webhook.

No server involved. The webhook URL is baked in at build time (config.py,
written by build_static.py). The player's name and personal best are kept in
the browser's localStorage.
"""

import asyncio
import json
import re
import sys

import pygame

from game_core import (CYAN, GREEN, HEIGHT, ORANGE, SKY, WHITE, WIDTH, Game,
                       Renderer)

try:
    from config import WEBHOOK_URL
except ImportError:
    WEBHOOK_URL = ""

IS_WEB = sys.platform == "emscripten"
NAME_MAX = 14

JS_BRIDGE = """
window.fireline_result = "";
window.fireline_getname = function () {
  return localStorage.getItem("fireline_name") || "";
};
window.fireline_setname = function (n) {
  localStorage.setItem("fireline_name", n);
};
window.fireline_best = function () {
  return localStorage.getItem("fireline_best") || "0";
};
window.fireline_setbest = function (v) {
  localStorage.setItem("fireline_best", String(v));
};
window.fireline_attempt = function (url, type, body) {
  return fetch(url, {method: "POST", headers: {"Content-Type": type}, body: body})
    .then(function (r) {
      return r.text().then(function (t) {
        var d = {};
        try { d = JSON.parse(t); } catch (e) {}
        return r.ok && d.ok !== false ? "ok" : "HTTP " + r.status + " " + (d.error || "");
      });
    });
};
window.fireline_send = function (url, payload) {
  window.fireline_result = "";
  var form = new URLSearchParams(JSON.parse(payload)).toString();
  // text/plain avoids a CORS preflight; Slack's endpoint rejects JSON preflights.
  window.fireline_attempt(url, "text/plain;charset=UTF-8", payload)
    .then(function (r) {
      return r === "ok" ? r : window.fireline_attempt(
        url, "application/x-www-form-urlencoded", form);
    })
    .then(function (r) { window.fireline_result = r; })
    .catch(function () { window.fireline_result = "network error"; });
};
window.fireline_take = function () {
  var r = window.fireline_result; window.fireline_result = ""; return r;
};
"""


def clean_name(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9 ._-]", "", name).strip()[:NAME_MAX]


class Bridge:
    """Talks to the hosting page's JavaScript; a no-op outside the browser."""

    def __init__(self):
        self.win = None
        self.name = ""
        self.best = 0
        if IS_WEB:
            import platform
            self.win = platform.window
            self.win.eval(JS_BRIDGE)
            self.best = self._int(self.win.fireline_best())
            self.name = clean_name(str(self.win.fireline_getname()))

    @staticmethod
    def _int(value) -> int:
        try:
            return int(str(value))
        except ValueError:
            return 0

    @property
    def enabled(self) -> bool:
        return bool(self.win and WEBHOOK_URL)

    def set_name(self, name: str) -> None:
        self.name = clean_name(name) or "PLAYER"
        self.win.fireline_setname(self.name)
    def post_if_best(self, game: Game) -> str:
        """Return a result: 'pending', 'no-best' (not posted) or 'disabled'."""
        if not self.enabled:
            return "disabled"
        if game.score <= self.best:
            return "no-best"
        self.best = game.score
        self.win.fireline_setbest(game.score)
        payload = {"name": self.name or "PLAYER", "score": str(game.score),
                   "wave": str(game.wave), "homes": str(sum(game.homes))}
        self.win.fireline_send(WEBHOOK_URL, json.dumps(payload))
        return "pending"

    def poll(self) -> str:
        return str(self.win.fireline_take()) if self.win else ""


def draw_result(renderer: Renderer, result: str, best: int) -> None:
    s = renderer.surface
    panel = pygame.Surface((390, 54))
    panel.fill(SKY)
    panel.set_alpha(238)
    s.blit(panel, (45, 220))
    pygame.draw.line(s, ORANGE, (58, 222), (422, 222))
    if result == "pending":
        renderer.text("SENDING TO SLACK...", 240, 232, CYAN, center=True)
    elif result == "ok":
        renderer.text("NEW BEST - POSTED TO SLACK!", 240, 232, GREEN, center=True)
    elif result == "no-best":
        renderer.text(f"YOUR BEST IS {best:06d}", 240, 232, WHITE, center=True)
    else:
        renderer.text("SCORE NOT POSTED", 240, 226, ORANGE, center=True)
        renderer.text(result.upper()[:44], 240, 248, WHITE, renderer.small, True)


def typed_char(event) -> str:
    """Character for a KEYDOWN; the browser build leaves event.unicode empty."""
    ch = event.unicode if len(getattr(event, "unicode", "")) == 1 else ""
    key = event.key
    if not ch:
        if pygame.K_a <= key <= pygame.K_z:
            ch = chr(key).upper() if event.mod & pygame.KMOD_SHIFT else chr(key)
        elif pygame.K_0 <= key <= pygame.K_9:
            ch = chr(key)
        else:
            ch = {pygame.K_SPACE: " ", pygame.K_MINUS: "-", pygame.K_PERIOD: "."}.get(key, "")
    return ch if ch and clean_name("a" + ch) == "a" + ch.strip() else ""


def draw_name_entry(renderer: Renderer, typed: str) -> None:
    s = renderer.surface
    pygame.draw.rect(s, SKY, (45, 114, 390, 132))
    pygame.draw.line(s, ORANGE, (58, 117), (422, 117))
    renderer.text("ENTER YOUR NAME", 240, 135, ORANGE, renderer.title, True)
    renderer.text(typed + "_", 240, 178, WHITE, center=True)
    renderer.text("SHOWN ON THE SLACK LEADERBOARD", 240, 204, CYAN, renderer.small, True)
    renderer.text("PRESS ENTER TO START", 240, 224, WHITE, renderer.small, True)


async def main() -> None:
    pygame.display.init()
    pygame.font.init()
    window = pygame.display.set_mode((960, 720), pygame.RESIZABLE)
    pygame.display.set_caption("FIRELINE - Wildfire Defense")
    renderer = Renderer()
    game = Game()
    bridge = Bridge()
    game.best = bridge.best
    clock = pygame.time.Clock()
    status = "SLACK LEADERBOARD ON" if bridge.enabled else "OFFLINE - NO WEBHOOK"
    result = ""
    naming, typed = False, ""
    last_phase = game.phase
    last_spray = False
    while True:
        dt = min(clock.tick(60) / 1000, 0.05)
        sw, sh = window.get_size()
        scale = min(sw / WIDTH, sh / HEIGHT)
        size = (max(1, int(WIDTH * scale)), max(1, int(HEIGHT * scale)))
        offset = ((sw - size[0]) // 2, (sh - size[1]) // 2)
        start_requested = False
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return
            if naming:
                if event.type != pygame.KEYDOWN:
                    continue
                if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    if clean_name(typed):
                        bridge.set_name(typed)
                        naming = False
                        game.start()
                elif event.key == pygame.K_BACKSPACE:
                    typed = typed[:-1]
                elif event.key == pygame.K_ESCAPE:
                    naming = False
                elif len(typed) < NAME_MAX:
                    typed += typed_char(event)
                continue
            if event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_p):
                if game.phase == "playing":
                    game.phase = "paused"
                elif game.phase == "paused":
                    game.phase = "playing"
                else:
                    start_requested = True
            elif event.type == pygame.WINDOWFOCUSLOST and game.phase == "playing":
                game.phase = "paused"
            elif event.type == pygame.MOUSEMOTION:
                game.point_at((event.pos[0] - offset[0]) / scale,
                              (event.pos[1] - offset[1]) / scale)
        keys = pygame.key.get_pressed()
        direction = pygame.Vector2(keys[pygame.K_RIGHT] + keys[pygame.K_d]
                                   - keys[pygame.K_LEFT] - keys[pygame.K_a],
                                   keys[pygame.K_DOWN] + keys[pygame.K_s]
                                   - keys[pygame.K_UP] - keys[pygame.K_w])
        spray = bool(keys[pygame.K_SPACE] or keys[pygame.K_b]
                     or pygame.mouse.get_pressed()[0])
        if spray and not last_spray and not naming:
            if game.phase in ("title", "over"):
                start_requested = True
            elif game.phase == "paused":
                game.phase = "playing"
        last_spray = spray
        if start_requested:
            if bridge.enabled and not bridge.name:
                naming, typed = True, ""
            else:
                game.start()
        game.update(dt, direction, spray)

        if game.phase == "over" and last_phase != "over":
            result = bridge.post_if_best(game)
        elif game.phase == "playing" and last_phase == "over":
            result = ""
        last_phase = game.phase
        if result == "pending":
            result = bridge.poll() or "pending"

        window.fill((4, 6, 12))
        surface = renderer.draw(game, status, pygame.time.get_ticks() / 1000)
        if game.phase == "over" and result != "disabled":
            draw_result(renderer, result, bridge.best)
        if naming:
            draw_name_entry(renderer, typed)
        window.blit(pygame.transform.scale(surface, size), offset)
        pygame.display.flip()
        await asyncio.sleep(0)


if IS_WEB or __name__ == "__main__":
    asyncio.run(main())
